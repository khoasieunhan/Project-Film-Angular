Please read me
Step 1: Extra file zip
Step 2: Open project with visual code 
Step 3: Install project with terminal (npm install)
Step 4: Finish!