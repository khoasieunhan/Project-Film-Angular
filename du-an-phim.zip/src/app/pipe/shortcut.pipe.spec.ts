import { ShortcutPipe } from './shortcut.pipe';

describe('ShortcutPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortcutPipe();
    expect(pipe).toBeTruthy();
  });
});
