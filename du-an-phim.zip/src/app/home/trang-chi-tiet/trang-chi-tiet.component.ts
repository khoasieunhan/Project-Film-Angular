import { Component, OnInit, OnDestroy, AfterViewInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PhimServiceService } from 'src/app/service/phim-service.service';
import { Subscription, pipe } from 'rxjs';
import { Title } from '@angular/platform-browser';
import * as moment from 'moment'; // add this 1 of 4
import WOW from 'wow.js';
import { ChatService } from 'src/app/websocket/chat.service';
import { ModalHistoryService } from 'src/app/service/modal-history.service';
import { NgDungServiceService } from 'src/app/service/ng-dung-service.service';

declare var $: any;

@Component({
  selector: 'app-trang-chi-tiet',
  templateUrl: './trang-chi-tiet.component.html',
  styleUrls: ['./trang-chi-tiet.component.css'],
  providers: [ChatService]
})
export class TrangChiTietComponent implements OnInit, OnDestroy, AfterViewInit {
  public currentRate = 3;

  public MaPhim: string;

  public ChiTietPhim: any = {};

  public TrailerPhim: string;

  private subParam: Subscription;

  currentDate: any;
  weekStart: any;
  weekEnd: any;
  days: any = [];
  weekDays: any;
  selectedDate: any;
  public nguoiDung: any = {};
  public isLogin = false;
  public isLoginFB = false;
  public isLoginGG = false;
  public TaiKhoan: any;
  public hisToryTicket: any;
  public userSocial: any;
  public user: any;
  public img: any;
  public messageText: any;
  public hiden = false;
  messageArray: Array<{user: any, message: any, img: any}> = [];
  // messageArray: String[] = [];


  // tslint:disable-next-line:max-line-length
  constructor(private activated: ActivatedRoute, private phimService: PhimServiceService, private svNguoiDung: NgDungServiceService, private titleService: Title, private chat: ChatService, private modalNgDungHistory: ModalHistoryService) {
    for (let i = 0; i <= 6; i++) {
      this.days.push(moment(this.weekStart).add(i, 'days'));
    }

    this.chat.newMessageReceived().subscribe((data) => {
      this.messageArray.push(data);
    });
  }

  TodoCtrl (day) {
    // this.selectedDate = day;
    const currentDate = moment();
    const weekStart = currentDate.clone().startOf('week');
    // const weekEnd = currentDate.clone().endOf('week');
    const days = [];
    for (let i = 0; i <= 6; i++) {
      days.push(moment(weekStart).add(i, 'days'));
    }
      // day.active = !day.active;
      day.weekDays = days;
  }

  sendMessage() {
    if (localStorage.getItem('nguoiDung')) {
      this.nguoiDung = JSON.parse(localStorage.getItem('nguoiDung'));
      this.user = this.nguoiDung.TaiKhoan;
      this.chat.sendMessage({user: this.user, message: this.messageText, img: 'khoa'});
      (document.querySelector('.commentHide') as HTMLElement).style.display = 'block';
    } else if (localStorage.getItem('faceBook')) {
      this.userSocial = JSON.parse(localStorage.getItem('faceBook'));
      this.user = this.userSocial.name;
      this.img = this.userSocial.image;
      this.chat.sendMessage({user: this.user, message: this.messageText, img: this.img});
      (document.querySelector('.commentHide') as HTMLElement).style.display = 'block';
      this.hiden = true;
    } else if (localStorage.getItem('google')) {
      this.userSocial = JSON.parse(localStorage.getItem('google'));
      this.user = this.userSocial.name;
      this.img = this.userSocial.image;
      this.chat.sendMessage({user: this.user, message: this.messageText, img: this.img});
      (document.querySelector('.commentHide') as HTMLElement).style.display = 'block';
    }
  }

  ngOnInit() {
    // this.titleService.setTitle(this.ChiTietPhim.TenPhim);
    this.subParam = this.activated.queryParams.subscribe(
      (params) => {
        this.MaPhim = params.MaPhim;
        this.titleService.setTitle(params.TenPhim);
        this.phimService.LayChiTietPhim(this.MaPhim).subscribe(
          (res) => {
            this.ChiTietPhim = res;
            console.log(this.ChiTietPhim);
            let traiLer = this.ChiTietPhim.Trailer;
            traiLer = traiLer.split('watch?v=');
            this.TrailerPhim = traiLer[1];
          });
      });

    this.currentDate = moment();
    this.weekStart = this.currentDate.clone().startOf('week');
    this.weekEnd = this.currentDate.clone().endOf('week');
    this.weekDays = this.days;
    this.selectedDate = this.weekDays[0];
  }

  ngOnDestroy() {
    this.subParam.unsubscribe();
  }

  ngAfterViewInit() {
    $(document).ready(function () {
      $('.js-modal-btn').modalVideo();
    });

    $(document).ready(function () {
      $('.btnBuyTicketDetail').click(function () {
        $('html, body').animate({
          scrollTop: $('#myTabContent').offset().top
        }, 1000);
      });
    });

    const wow = new WOW();
    wow.init();

     // Kiểm tra trong storage có tài khoản người dùng chưa
     if (localStorage.getItem('nguoiDung')) {
      this.nguoiDung = JSON.parse(localStorage.getItem('nguoiDung'));
      this.TaiKhoan = this.nguoiDung.TaiKhoan;
      this.isLogin = true;
      this.svNguoiDung.HistoryTicket(this.TaiKhoan).subscribe(
        (data: any) => {
          this.hisToryTicket = data.DanhSachVeDaDat;
          localStorage.setItem('hisTory', JSON.stringify(this.hisToryTicket));
          // tslint:disable-next-line:max-line-length
          const object = { isOpen: true, hisTory: data.TaiKhoan, hisToryTicket: this.hisToryTicket, Title: 'History buy ticket - ' + data.TaiKhoan };
          this.modalNgDungHistory.setIsOpenModal(object);
          this.modalNgDungHistory.data.emit(JSON.stringify(object));
        });
    }

    // tslint:disable-next-line:curly
    if (localStorage.getItem('faceBook')) {
      this.userSocial = JSON.parse(localStorage.getItem('faceBook'));
      // (document.querySelector('.googleLogin') as HTMLElement).style.display = 'none';
      // (document.querySelector('.loginAcc') as HTMLElement).style.display = 'none';
      // (document.querySelector('.signUp') as HTMLElement).style.display = 'none';
      this.isLoginFB = true;
    }

    if (localStorage.getItem('google')) {
      this.userSocial = JSON.parse(localStorage.getItem('google'));
      // (document.querySelector('.FBlogin') as HTMLElement).style.display = 'none';
      // (document.querySelector('.loginAcc') as HTMLElement).style.display = 'none';
      // (document.querySelector('.signUp') as HTMLElement).style.display = 'none';
      this.isLoginGG = true;
    }

    (document.querySelector('.commentHide') as HTMLElement).style.display = 'none';

  }
}
