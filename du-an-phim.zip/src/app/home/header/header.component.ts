import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { NgDungServiceService } from 'src/app/service/ng-dung-service.service';
import swal from 'sweetalert2';
import { ModalHistoryService } from 'src/app/service/modal-history.service';
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider
} from 'angular-6-social-login';
import { NguoiDung } from 'src/app/models/nguoiDung';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy, AfterViewInit {
  public nguoiDung: any = {};
  public dangKy: any = {};
  public isLogin = false;
  public isLoginFB = false;
  public isLoginGG = false;
  public sub: Subscription;
  public TaiKhoan: any;
  public MatKhau: any;
  public hisToryTicket: any;
  public userSocial: any;
  public layDanhSachNguoiDung: NguoiDung[] = [];
  public layDanhSachNguoiDungGB2: NguoiDung[] = [];

  // tslint:disable-next-line:max-line-length
  constructor(private svNguoiDung: NgDungServiceService, private modalNgDungHistory: ModalHistoryService, private socialAuthService: AuthService) { }

  ngOnInit() {
    this.svNguoiDung.LayDanhSachNguoiDung().subscribe(
      (kq: any) => {
        this.layDanhSachNguoiDung = kq;
        console.log(kq);
        localStorage.setItem('ngDung', JSON.stringify(this.layDanhSachNguoiDung));
      },
      (error: any) => {
        console.log(error);
      }
    );

    this.svNguoiDung.LayDanhSachNguoiDungGB2().subscribe(
      (kq: any) => {
        this.layDanhSachNguoiDungGB2 = kq;
        console.log(kq);
        localStorage.setItem('ngDung2', JSON.stringify(this.layDanhSachNguoiDungGB2));
      },
      (eror: any) => {
        console.log(eror);
      }
    );

  }

  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform === 'facebook') {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform === 'google') {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    }
    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        if (socialPlatform === 'facebook') {
          const pushMaloai = {
            MaNhom: 'GP02',
            MaLoaiNguoiDung: 'KhachHang'
          };
          const pushInfor = {
            TaiKhoan: userData.provider,
            MatKhau: userData.id,
            HoTen: userData.name,
            Email: userData.email,
            MaNhom: 'GP02',
            MaLoaiNguoiDung: 'KhachHang'
          };
          // tslint:disable-next-line:max-line-length
          this.sub = this.svNguoiDung.DangKy2(pushInfor, pushMaloai).subscribe((ketqua: any) => {
            if (ketqua !== 'Tài khoản đã tồn tại') {
              this.dangKy = ketqua;
              this.isLogin = false;
              // swal({
              //   type: 'success',
              //   title: 'Good job!',
              //   text: 'Sign Up Success!',
              // }).then(function () {
              //   location.reload();
              // });
              // Lưu vào storage
              localStorage.setItem('dangKy', JSON.stringify(this.dangKy)); // Lưu storage
              // location.reload(); // Load lại trang sau khi đăng nhập thành công
              this.TaiKhoan = userData.email;
              this.MatKhau = userData.id;
              // tslint:disable-next-line:no-shadowed-variable
              this.sub = this.svNguoiDung.DangNhap(this.TaiKhoan, this.MatKhau).subscribe((ketqua) => {
                if (ketqua !== 'Tài khoản hoặc mật khẩu không đúng !') {
                  this.nguoiDung = ketqua;
                  console.log(this.nguoiDung);
                  this.isLogin = false;
                  swal({
                    type: 'success',
                    title: 'Good job!',
                    text: 'Logged in successfully!',
                  }).then(function () {
                    location.reload();
                  });
                  // Lưu vào storage
                  localStorage.setItem('nguoiDung', JSON.stringify(this.nguoiDung)); // Lưu storage
                  location.reload(); // Load lại trang sau khi đăng nhập thành công
                } else {
                  this.nguoiDung = {};
                  this.isLogin = true;
                  localStorage.setItem('nguoiDung', '');
                }
              });
            }
          });
          this.isLoginFB = false;
          this.userSocial = userData;
          localStorage.setItem('faceBook', JSON.stringify(userData));
          location.reload();
        } else if (socialPlatform === 'google') {
          const pushMaloai = {
            MaNhom: 'GP01',
            MaLoaiNguoiDung: 'KhachHang'
          };
          const pushInfor = {
            TaiKhoan: userData.email,
            MatKhau: userData.id,
            HoTen: userData.name,
            Email: userData.email,
            MaNhom: 'GP01',
            MaLoaiNguoiDung: 'KhachHang'
          };
          // tslint:disable-next-line:max-line-length
          this.sub = this.svNguoiDung.DangKy2(pushInfor, pushMaloai).subscribe((ketqua: any) => {
            if (ketqua !== 'Tài khoản đã tồn tại') {
              this.dangKy = ketqua;
              this.isLogin = false;
              // swal({
              //   type: 'success',
              //   title: 'Good job!',
              //   text: 'Sign Up Success!',
              // }).then(function () {
              //   location.reload();
              // });
              // Lưu vào storage
              localStorage.setItem('dangKy', JSON.stringify(this.dangKy)); // Lưu storage
              // location.reload(); // Load lại trang sau khi đăng nhập thành công
              this.TaiKhoan = userData.email;
              this.MatKhau = userData.id;
              // tslint:disable-next-line:no-shadowed-variable
              this.sub = this.svNguoiDung.DangNhap(this.TaiKhoan, this.MatKhau).subscribe((ketqua) => {
                if (ketqua !== 'Tài khoản hoặc mật khẩu không đúng !') {
                  this.nguoiDung = ketqua;
                  console.log(this.nguoiDung);
                  this.isLogin = false;
                  swal({
                    type: 'success',
                    title: 'Good job!',
                    text: 'Logged in successfully!',
                  }).then(function () {
                    location.reload();
                  });
                  // Lưu vào storage
                  localStorage.setItem('nguoiDung', JSON.stringify(this.nguoiDung)); // Lưu storage
                  // location.reload(); // Load lại trang sau khi đăng nhập thành công
                } else {
                  this.nguoiDung = {};
                  this.isLogin = true;
                  localStorage.setItem('nguoiDung', '');
                }
              });
            }
          });
          this.isLoginGG = false;
          this.userSocial = userData;
          localStorage.setItem('google', JSON.stringify(userData));
          // location.reload();
        }
      }
    );
  }

  DangNhap(taikhoan: string, matkhau: string) {
    // Gọi service đăng nhập
    this.sub = this.svNguoiDung.DangNhap(taikhoan, matkhau).subscribe((ketqua) => {
      if (ketqua !== 'Tài khoản hoặc mật khẩu không đúng !') {
        this.nguoiDung = ketqua;
        console.log(this.nguoiDung);
        this.isLogin = false;
        swal({
          type: 'success',
          title: 'Good job!',
          text: 'Logged in successfully!',
        }).then(function () {
          location.reload();
        });
        // Lưu vào storage
        localStorage.setItem('nguoiDung', JSON.stringify(this.nguoiDung)); // Lưu storage
        // location.reload(); // Load lại trang sau khi đăng nhập thành công
      } else {
        this.nguoiDung = {};
        this.isLogin = true;
        localStorage.setItem('nguoiDung', '');
      }
    });
  }

  DangXuat() {
    localStorage.removeItem('nguoiDung');
    localStorage.setItem('nguoiDung', '');
    localStorage.setItem('mangVe', '');
    localStorage.setItem('mangVe', '');
    localStorage.setItem('chiTietPhim', '');
    localStorage.setItem('lichChieu', '');
    localStorage.setItem('ngDung', '');
    localStorage.setItem('Admin', '');
    localStorage.setItem('hisTory', '');
    localStorage.setItem('faceBook', '');
    localStorage.setItem('google', '');
    location.href = ''; // Load lại trang sau khi đăng xuất
  }

  // tslint:disable-next-line:no-shadowed-variable
  DangKy(NguoiDung: any) {
    const pushMaloai = {
      MaNhom: NguoiDung.MaNhom = 'GP01',
      MaLoaiNguoiDung: NguoiDung.MaLoaiNguoiDung = 'KhachHang'
    };
    console.log(NguoiDung);
    // tslint:disable-next-line:max-line-length
    this.sub = this.svNguoiDung.DangKy2(NguoiDung, pushMaloai).subscribe((ketqua: any) => {
      if (ketqua !== 'Tài khoản đã tồn tại') {
        this.dangKy = ketqua;
        this.isLogin = false;
        swal({
          type: 'success',
          title: 'Good job!',
          text: 'Sign Up Success!',
        }).then(function () {
          location.reload();
        });
        // Lưu vào storage
        localStorage.setItem('dangKy', JSON.stringify(this.dangKy)); // Lưu storage
        // location.reload(); // Load lại trang sau khi đăng nhập thành công
      } else {
        swal({
          type: 'error',
          title: 'error!',
          text: 'Sign Up Failed!',
        }).then(function () {
          location.reload();
        });
        this.dangKy = {};
        this.isLogin = true;
        localStorage.setItem('dangKy', '');
      }
    });
  }

  ngOnDestroy() {
    // this.sub.unsubscribe();
  }

  ngAfterViewInit() {

    // Kiểm tra trong storage có tài khoản người dùng chưa
    if (localStorage.getItem('nguoiDung')) {
      this.nguoiDung = JSON.parse(localStorage.getItem('nguoiDung'));
      this.TaiKhoan = this.nguoiDung.TaiKhoan;
      this.isLogin = true;
      this.svNguoiDung.HistoryTicket(this.TaiKhoan).subscribe(
        (data: any) => {
          console.log(data);
          this.hisToryTicket = data.DanhSachVeDaDat;
          localStorage.setItem('hisTory', JSON.stringify(this.hisToryTicket));
          console.log(this.hisToryTicket);
          // tslint:disable-next-line:max-line-length
          const object = { isOpen: true, hisTory: data.TaiKhoan, hisToryTicket: this.hisToryTicket, Title: 'History buy ticket - ' + data.TaiKhoan };
          console.log(object);
          this.modalNgDungHistory.setIsOpenModal(object);
          this.modalNgDungHistory.data.emit(JSON.stringify(object));
        });
    }

    // tslint:disable-next-line:curly
    if (localStorage.getItem('faceBook')) {
      this.userSocial = JSON.parse(localStorage.getItem('faceBook'));
      (document.querySelector('.googleLogin') as HTMLElement).style.display = 'none';
      (document.querySelector('.loginAcc') as HTMLElement).style.display = 'none';
      (document.querySelector('.signUp') as HTMLElement).style.display = 'none';
      this.isLoginFB = true;
    }

    if (localStorage.getItem('google')) {
      this.userSocial = JSON.parse(localStorage.getItem('google'));
      (document.querySelector('.FBlogin') as HTMLElement).style.display = 'none';
      (document.querySelector('.loginAcc') as HTMLElement).style.display = 'none';
      (document.querySelector('.signUp') as HTMLElement).style.display = 'none';
      this.isLoginGG = true;
    }
  }
}
