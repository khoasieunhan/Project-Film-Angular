import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { NgDungServiceService } from 'src/app/service/ng-dung-service.service';
import swal from 'sweetalert2';
import { Router } from '@angular/router';
import { ModalHistoryService } from 'src/app/service/modal-history.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  public nguoiDung: any = {};
  public dangKy: any = {};
  public isLogin = false;
  public sub: Subscription;
  public TaiKhoan: any;
  public hisToryTicket: any;
  constructor(private svNguoiDung: NgDungServiceService, private router: Router, private modalNgDungHistory: ModalHistoryService) { }

  ngOnInit() {
    // Kiểm tra trong storage có tài khoản người dùng chưa
    if (localStorage.getItem('nguoiDung')) {
      this.nguoiDung = JSON.parse(localStorage.getItem('nguoiDung'));
      this.TaiKhoan = this.nguoiDung.TaiKhoan;
      this.isLogin = true;
      this.svNguoiDung.HistoryTicket(this.TaiKhoan).subscribe(
        (data: any) => {
          console.log(data);
          this.hisToryTicket = data.DanhSachVeDaDat;
          localStorage.setItem('hisTory', JSON.stringify(this.hisToryTicket));
          console.log(this.hisToryTicket);
          // tslint:disable-next-line:max-line-length
          const object = { isOpen: true, hisTory: data.TaiKhoan, hisToryTicket: this.hisToryTicket, Title: 'History buy ticket - ' + data.TaiKhoan };
          console.log(object);
          this.modalNgDungHistory.setIsOpenModal(object);
          this.modalNgDungHistory.data.emit(JSON.stringify(object));
        });
    }
  }

  DangNhap(taikhoan: string, matkhau: string) {
    // Gọi service đăng nhập
    this.sub = this.svNguoiDung.DangNhap(taikhoan, matkhau).subscribe((ketqua) => {
      if (ketqua !== 'Tài khoản hoặc mật khẩu không đúng !') {
        console.log(ketqua);
        this.nguoiDung = ketqua;
        this.isLogin = false;
        swal({
          type: 'success',
          title: 'Good job!',
          text: 'Logged in successfully!',
        }).then(function () {
          location.reload();
        });
        // Lưu vào storage
        localStorage.setItem('nguoiDung', JSON.stringify(this.nguoiDung)); // Lưu storage
        // location.reload(); // Load lại trang sau khi đăng nhập thành công
      } else {
        this.nguoiDung = {};
        this.isLogin = true;
        localStorage.setItem('nguoiDung', '');
      }
    });

  }

  DangXuat() {
    localStorage.removeItem('nguoiDung');
    localStorage.setItem('mangVe', '');
    localStorage.setItem('mangVe', '');
    localStorage.setItem('chiTietPhim', '');
    localStorage.setItem('lichChieu', '');
    localStorage.setItem('ngDung', '');
    localStorage.setItem('Admin', '');
    localStorage.setItem('hisTory', '');
    location.href = ''; // Load lại trang sau khi đăng xuất
  }

  DangKy(NguoiDung: any) {
    const pushMaloai = {
      MaNhom: NguoiDung.MaNhom = 'GP01',
      MaLoaiNguoiDung: NguoiDung.MaLoaiNguoiDung = 'KhachHang'
    };
    console.log(NguoiDung);
    // tslint:disable-next-line:max-line-length
    this.sub = this.svNguoiDung.DangKy(NguoiDung, pushMaloai).subscribe((ketqua: any) => {
      if (ketqua !== 'Đăng ký thất bại') {
        this.dangKy = ketqua;
        this.isLogin = false;
        swal({
          type: 'success',
          title: 'Good job!',
          text: 'Sign Up Success!',
        }).then(function () {
          location.reload();
        });
        // Lưu vào storage
        localStorage.setItem('dangKy', JSON.stringify(this.dangKy)); // Lưu storage
        location.reload(); // Load lại trang sau khi đăng nhập thành công
      } else {
        this.dangKy = {};
        this.isLogin = true;
        localStorage.setItem('dangKy', '');
      }
    });
  }

  ngOnDestroy() {
    // this.sub.unsubscribe();
  }
}
