import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { MomentModule } from 'ngx-moment';
import { AdminModule } from './admin/admin.module';
import { AuthGuard } from './guard/auth.guard';
import { ModalModule } from './modal/modal.module';
import { SlickCarouselModule } from 'ngx-slick-carousel';

// import { ExportAsModule } from 'ngx-export-as';

// const appRoutes: Routes = [
//   { path: '', loadChildren: () => HomeModule },
//   { path: 'home', loadChildren: () => HomeModule },
//   { path: 'admin', loadChildren: () => AdminModule },
// ];

// , canActivate: [AuthGuard]

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    AdminModule,
    BrowserAnimationsModule,
    HttpModule,
    ModalModule,
    SlickCarouselModule,
    // ExportAsModule,
    // RouterModule.forRoot(appRoutes),
    MomentModule
  ],
  providers: [Title],
  bootstrap: [AppComponent]
})
export class AppModule { }
