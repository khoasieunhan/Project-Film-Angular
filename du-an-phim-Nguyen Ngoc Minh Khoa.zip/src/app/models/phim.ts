export class Phim {
    public MaPhim: any;
    public TenPhim: string;
    public Trailer: string;
    public HinhAnh: string;
    public MoTa: string;
    public MaNhom: string;
    public NgayKhoiChieu: string;
    public DanhGia: string;
}
