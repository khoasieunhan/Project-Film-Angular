export class RapPhim {
    public RapPhim: string;
    public TenRap: string;
    public image: string;
}
